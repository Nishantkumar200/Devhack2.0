<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
<link rel="stylesheet" href="style.css">
<!-- Mobile Specific Meta -->
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Magazine</title>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		<link rel="stylesheet" href="css/nice-select.css">
		<link rel="stylesheet" href="css/animate.min.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/jquery-ui.css">
		<link rel="stylesheet" href="css/main.css">
<title>VIew profile</title>
</head>
<body>
<div class="logo-wrap">
				<div class="container">
					<div class="row justify-content-between align-items-center">
						<div class="col-lg-4 col-md-4 col-sm-12 logo-left no-padding">
							<a href="index.html">
								
							</a>
						</div>
						<div class="col-lg-8 col-md-8 col-sm-12 logo-right no-padding ads-banner">
							<img class="img-fluid" src="img/banner-ad.jpg" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="container main-menu" id="main-menu">
				<div class="row align-items-center justify-content-between">
					<nav id="nav-menu-container">
						<ul class="nav-menu">
							<li class="menu-active"><a href="index_company.php">Home</a></li>
						
							<li><a href="profile_company.php">Profile</a></li>
							<li class="menu-has-children"><a href="findfarmers.php">Find Farmers</a>
							<li class="menu-has-children"><a href="comprequests.php">Requests Sent</a>
						</li>
						
					</ul>
					</nav><!-- #nav-menu-container -->

				</div>
			</div>
		</header>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>


<?php
    session_start();
    if (isset($_GET['sid'])) {
        $_SESSION['tid'] = $_GET['sid'];
        $conn = new mysqli('localhost','root', '', 'devhack2');
        if ($conn->connect_error) die("Fatal Error");
          $query="select * from farmer where id ='{$_GET['sid']}'";
        $result   = $conn->query($query);
          $users = $result->num_rows;
          if($users == 1) {
          for($i=0;$i<$users;$i++) {
            $row = $result->fetch_array(MYSQLI_NUM);
            $r0 = htmlspecialchars($row[0]);
            $r1 = htmlspecialchars($row[1]);
            $r2 = htmlspecialchars($row[2]);
            $r3 = htmlspecialchars($row[3]);
            $r4 = htmlspecialchars($row[4]);
            $r5 = htmlspecialchars($row[5]);
            $r6 = htmlspecialchars($row[6]);
            $r7 = htmlspecialchars($row[7]);
            $r8 = htmlspecialchars($row[8]);
            $r9 = htmlspecialchars($row[9]);
            //echo "*ID- ".$r0."<br>*Username- ".$r1."<br>*Password- ".$r2."<br>*Name- ".$r3."<br>*Mobile- ".$r4."<br>*Email- ".$r5."<br>*Address- ".$r6."<br>*Crops Preferred- ".$r7."<br>*State- ".$r8."<br>*District- ".$r9."<br><br>";
            ?>
           <div class="container">
               <div class="card">
                   <div class="card-header bg-primary">
                       <h3 class=" text-white">Personal's Details</h3>
                   </div>
                   <div class="card-body">
                       <table class="table">
                           <tr>
                           <th>Username:</th>
                           <td><?php echo $r1?></td>
                           </tr>
                           <tr>
                           <th>Password:</th>
                           <td><?php echo $r2?></td>
                           </tr>
                           <tr>
                           <th>Name:</th>
                           <td><?php echo $r3?></td>
                           </tr>
                           <tr>
                           <th>Mobile:</th>
                           <td><?php echo $r4?></td>
                           </tr>
                           <tr>
                           <th>E-mail:</th>
                           <td><?php echo $r5?></td>
                           </tr>
                           <tr>
                           <th>Address:</th>
                           <td><?php echo $r6?></td>
                           </tr>
                           <tr>
                           <th>Crop:</th>
                           <td><?php echo $r7?></td>
                           </tr>
                           <tr>
                           <th>State:</th>
                           <td><?php echo $r8?></td>
                           </tr>
                           <tr>
                           <th>District:</th>
                           <td><?php echo $r9?></td>
                           </tr>
                          
                           
                          
                        
                       </table>
                   </div>
               </div>
               <form action="viewprofilecomp.php" method="post">
        <input type=submit name="Send_Request" class="btn btn-dark" value="Send Request">
    </form>
    
           </div>
           <?php
          }
        }

    }

    if(isset($_POST['Send_Request'])) {
        $conn = new mysqli('localhost','root', '', 'devhack2');
        if ($conn->connect_error) die("Fatal Error");

        $query="insert into compreq VALUES('{$_SESSION['id']}' , '{$_SESSION['tid']}', 'Request Sent')";
        $result   = $conn->query($query);
        if (!($result)) {
            echo "insertion failed.";
        }
        else {
            echo "Request sent successfully.";
        }
    }
?>

    

