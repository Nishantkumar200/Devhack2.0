<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
<link rel="stylesheet" href="css/style4.css">
<title>Search Union</title>
<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Magazine</title>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
		<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		<link rel="stylesheet" href="css/nice-select.css">
		<link rel="stylesheet" href="css/animate.min.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/jquery-ui.css">
		<link rel="stylesheet" href="css/main.css">
</head>
<body>
<div class="logo-wrap">
				<div class="container">
					<div class="row justify-content-between align-items-center">
						<div class="col-lg-4 col-md-4 col-sm-12 logo-left no-padding">
							<a href="index.html">
								
							</a>
						</div>
						
					</div>
				</div>
			</div>
			<div class="container main-menu" id="main-menu">
				<div class="row align-items-center justify-content-between">
					<nav id="nav-menu-container">
						<ul class="nav-menu">
							<li class="menu-active"><a href="index_farmer.php">Home</a></li>
						
							<li><a href="profile.php">Profile</a></li>
							<li class="menu-has-children"><a href="teamrequests.php">Team Requests</a>
							<li class="menu-has-children"><a href="farm_comp_requests.php">Company Requests</a>
						</li>
						
					</ul>
					</nav><!-- #nav-menu-container -->

				</div>
			</div>
		</header>
		<div class="container">
			
			<table class="table table-hover">
				<thead>
					<tr>
						<th>S.no</th>
						<th>Request From Company(ID)</th>
                        <th>Status</th>
                        <th>View Profile </th>
					</tr>
				</thead>
		
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>


<?php
    session_start();
    $conn = new mysqli('localhost','root', '', 'devhack2');
    if ($conn->connect_error) die("Fatal Error");
    $query="select * from compreq where to_id ='{$_SESSION['id']}'";
    $result   = $conn->query($query);
    $users = $result->num_rows;
    if($users >0) {
        for($i=0;$i<$users;$i++)
	            {
                    $i++;
	            	$row = $result->fetch_array(MYSQLI_NUM);
				    $r0 = htmlspecialchars($row[0]);
				    $r1 = htmlspecialchars($row[1]);
                    $r2 = htmlspecialchars($row[2]);
                    echo "<td>" .$i . "</td>";
                    echo "<td>" .$r0 . "</td>";
                    echo "<td>" .$r2 . "</td>";
                    echo "<td>" . "<a href='viewcompprofile.php?sid=".$r0."'>View Profile</a>" . "</td>";
                    $i--;

                  }
    }
    else {
        echo "<td> No Requests sent yet! </td>";
    }
    
?>