<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
<link rel="stylesheet" href="css/style1.css">
<title>Registration form</title>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="card-body">
        <div class="card-header">
        <h4 class="text-primary text-center">Company Registration</h4>
        </div>
            <form action="company_registration.php" method="post">
            <span id="valid" class="text-success"></span>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" id="" required="required">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" id="" required="required">
            </div>

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" id="" required="required">
            </div>
            <div class="form-group">
                <label for="Mobile">Mobile</label>
                <input type="number" class="form-control" name="mobile" id="" required="required">
            </div>
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" class="form-control" name="email" id="" required="required">
            </div>
            <div class="form-group">
                <label for="adress">Address</label>
                <textarea name="address" id="" cols="30" rows="5" class="form-control" required="required"></textarea>
            </div>
            <div class="form-group">
                <label for="industry">Industry Type</label>
                <input type="text" class="form-control" name="industry" id="" required="required">
            </div>
            <input type="submit" class="btn btn-block btn-primary" name="register" id="" required="required">
            <small><i>Already have an account</i><a href="index.php"> Login</a></small>
            </form>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>



<?php
 $conn = mysqli_connect('localhost','root','','devhack2');

 if(isset($_POST['register'])){
     $user = $_POST['username'];
     $password = $_POST['password'];
     $name = $_POST['name'];
     $mobile = $_POST['mobile'];
     $email = $_POST['email'];
     $address = $_POST['address'];
     $industry = $_POST['industry'];
     
      
     $qry = "INSERT INTO `company_registration`(`username`, `password`, `name`, `mobile`, `email`, `address`, `industry`) 
     VALUES ('$user','$password ','$name','$mobile','$email','$address','$industry')";

     $run = mysqli_query($conn,$qry);
     if($run){
         ?>
         <script>
         document.getElementById('valid').innerHTML = "Successfully Registered";
         </script>
         <?php

     }

}


?>